package counter;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Count {

	public static void main(String[] args) {
		JFrame f = new JFrame("Words Counter");
        f.setSize(300, 300);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setResizable(false);
        f.setLocationRelativeTo(null);
        JTextArea a = new JTextArea();
        a.setPreferredSize(new Dimension(170, 100));
        a.setBorder(BorderFactory.createLineBorder(Color.BLUE));
        JLabel l1 = new JLabel("Enter sentence");
        JPanel p1 = new JPanel();
        p1.setLayout(new FlowLayout(FlowLayout.CENTER));
        p1.add(l1);
        p1.add(a);
        JButton b = new JButton("Count");
        JPanel p2 = new JPanel();
        p2.setLayout(new FlowLayout(FlowLayout.CENTER));
        p2.add(b);
        JLabel l2 = new JLabel("No. of Words: ");
        JLabel l3 = new JLabel("No. of Characters: ");
        JLabel l4 = new JLabel("No. of Sentences: ");
        JPanel p3 = new JPanel();
        p3.add(l2);
        p3.add(l3);
        Font font=new Font("Comic Sans MS",Font.PLAIN,12);
        Font font1=new Font("Comic Sans MS",Font.PLAIN,15);
        a.setBackground(Color.white);
        a.setForeground(Color.black);
        a.setFont(font1);
        b.setFont(font);
        l1.setFont(font);
        l2.setFont(font);
        l3.setFont(font);
        l4.setFont(font);
        b.addActionListener( new ActionListener (){
            @Override
            public void actionPerformed(ActionEvent e){
                String text= a.getText();  
                String words[]=text.split("\\s");  
                l2.setText("No. of Words: "+words.length);  
                l3.setText("No. of Characters: "+text.length());
                String[] s = text.split("[.?!]+");
                l4.setText("No. of Sentences: "+s.length);
            }
        });
        p3.add(l4);
        p3.setLayout(new BoxLayout(p3, BoxLayout.Y_AXIS));
        f.add(p3,BorderLayout.AFTER_LAST_LINE);
        f.add(p2,BorderLayout.CENTER);
        f.add(p1,BorderLayout.NORTH);
        f.setVisible(true);
	}

}
