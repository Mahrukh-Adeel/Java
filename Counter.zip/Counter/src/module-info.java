module Counter {
	requires java.desktop;
}